﻿namespace telefonrehberi
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnGuncelleGrup = new System.Windows.Forms.Button();
            this.btnEkleGrup = new System.Windows.Forms.Button();
            this.btnSilGrup = new System.Windows.Forms.Button();
            this.btnYeniKayıtGrup = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtAciklamaGrup = new System.Windows.Forms.TextBox();
            this.txtGrupAdiGrup = new System.Windows.Forms.TextBox();
            this.grdGruplar = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdGruplar)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnGuncelleGrup);
            this.groupBox1.Controls.Add(this.btnEkleGrup);
            this.groupBox1.Controls.Add(this.btnSilGrup);
            this.groupBox1.Controls.Add(this.btnYeniKayıtGrup);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtAciklamaGrup);
            this.groupBox1.Controls.Add(this.txtGrupAdiGrup);
            this.groupBox1.Location = new System.Drawing.Point(13, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(452, 197);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Grup Bilgi Girişi";
            // 
            // btnGuncelleGrup
            // 
            this.btnGuncelleGrup.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGuncelleGrup.Location = new System.Drawing.Point(282, 152);
            this.btnGuncelleGrup.Name = "btnGuncelleGrup";
            this.btnGuncelleGrup.Size = new System.Drawing.Size(113, 23);
            this.btnGuncelleGrup.TabIndex = 19;
            this.btnGuncelleGrup.Text = "GÜNCELLE";
            this.btnGuncelleGrup.UseVisualStyleBackColor = true;
            this.btnGuncelleGrup.Click += new System.EventHandler(this.btnGuncelleGrup_Click);
            // 
            // btnEkleGrup
            // 
            this.btnEkleGrup.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEkleGrup.Location = new System.Drawing.Point(44, 152);
            this.btnEkleGrup.Name = "btnEkleGrup";
            this.btnEkleGrup.Size = new System.Drawing.Size(113, 23);
            this.btnEkleGrup.TabIndex = 17;
            this.btnEkleGrup.Text = "EKLE";
            this.btnEkleGrup.UseVisualStyleBackColor = true;
            this.btnEkleGrup.Click += new System.EventHandler(this.btnEkleGrup_Click);
            // 
            // btnSilGrup
            // 
            this.btnSilGrup.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSilGrup.Location = new System.Drawing.Point(163, 152);
            this.btnSilGrup.Name = "btnSilGrup";
            this.btnSilGrup.Size = new System.Drawing.Size(113, 23);
            this.btnSilGrup.TabIndex = 18;
            this.btnSilGrup.Text = "SİL";
            this.btnSilGrup.UseVisualStyleBackColor = true;
            this.btnSilGrup.Click += new System.EventHandler(this.btnSilGrup_Click);
            // 
            // btnYeniKayıtGrup
            // 
            this.btnYeniKayıtGrup.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnYeniKayıtGrup.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnYeniKayıtGrup.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnYeniKayıtGrup.Location = new System.Drawing.Point(325, 16);
            this.btnYeniKayıtGrup.Name = "btnYeniKayıtGrup";
            this.btnYeniKayıtGrup.Size = new System.Drawing.Size(96, 30);
            this.btnYeniKayıtGrup.TabIndex = 16;
            this.btnYeniKayıtGrup.Text = "Yeni Kayıt";
            this.btnYeniKayıtGrup.UseVisualStyleBackColor = false;
            this.btnYeniKayıtGrup.Click += new System.EventHandler(this.btnYeniKayıtGrup_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(94, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Açıklama:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(96, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Grup Adı:";
            // 
            // txtAciklamaGrup
            // 
            this.txtAciklamaGrup.Location = new System.Drawing.Point(162, 56);
            this.txtAciklamaGrup.Multiline = true;
            this.txtAciklamaGrup.Name = "txtAciklamaGrup";
            this.txtAciklamaGrup.Size = new System.Drawing.Size(135, 84);
            this.txtAciklamaGrup.TabIndex = 1;
            // 
            // txtGrupAdiGrup
            // 
            this.txtGrupAdiGrup.Location = new System.Drawing.Point(162, 30);
            this.txtGrupAdiGrup.Name = "txtGrupAdiGrup";
            this.txtGrupAdiGrup.Size = new System.Drawing.Size(135, 20);
            this.txtGrupAdiGrup.TabIndex = 0;
            // 
            // grdGruplar
            // 
            this.grdGruplar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdGruplar.Location = new System.Drawing.Point(13, 217);
            this.grdGruplar.Name = "grdGruplar";
            this.grdGruplar.Size = new System.Drawing.Size(452, 306);
            this.grdGruplar.TabIndex = 1;
            this.grdGruplar.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grdGruplar_CellClick);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(477, 535);
            this.Controls.Add(this.grdGruplar);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form2";
            this.Text = "Grup";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdGruplar)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtAciklamaGrup;
        private System.Windows.Forms.TextBox txtGrupAdiGrup;
        private System.Windows.Forms.Button btnYeniKayıtGrup;
        private System.Windows.Forms.Button btnGuncelleGrup;
        private System.Windows.Forms.Button btnEkleGrup;
        private System.Windows.Forms.Button btnSilGrup;
        private System.Windows.Forms.DataGridView grdGruplar;
    }
}