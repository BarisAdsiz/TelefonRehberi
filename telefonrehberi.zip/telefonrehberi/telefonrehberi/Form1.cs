﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static telefonrehberi.VeriTabaniBaglantisi;

namespace telefonrehberi
{
    public partial class Form1 : Form
    {
        int secilikisiId = 0;
        public Form1()
        {
            InitializeComponent();
        }
       
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            BilgileriYukle();

        }
        private void BilgileriYukle()
        {
            Grup grup = new Grup();
            comboBox2.DataSource = grup.GruplariListele();
            comboBox2.ValueMember = "grup_id";
            comboBox2.DisplayMember = "grup_adi";
            DataTable araGrupDt=grup.GruplariListele();
            DataRow dr =araGrupDt.NewRow();
            dr["grup_adi"] = "Tümü";
            dr["grup_id"] = 0;
            araGrupDt.Rows.Add(dr);
            comboBox1.DataSource = araGrupDt;
            comboBox1.ValueMember = "grup_id";
            comboBox1.DisplayMember = "grup_adi";
            comboBox1.SelectedValue = 0;
            Kisi kisi=new Kisi();
            dataGridView1.DataSource = kisi.KisileriListele();
            dataGridView1.Columns["kisi_id"].HeaderText = "";
            dataGridView1.Columns["kisi_id"].Width = 0;
            dataGridView1.Columns["ad"].HeaderText = "kişi adı";
            dataGridView1.Columns["ad"].Width = 120;
            dataGridView1.Columns["soyad"].HeaderText = "kişi soyadı";
            dataGridView1.Columns["soyad"].Width = 90;
            dataGridView1.Columns["tel_no1"].HeaderText = "telefon No 1";
            dataGridView1.Columns["tel_no1"].Width = 110;
            dataGridView1.Columns["tel_no2"].HeaderText = "telefon No 2";
            dataGridView1.Columns["tel_no2"].Width = 110;
            dataGridView1.Columns["mail"].HeaderText = "mail";
            dataGridView1.Columns["mail"].Width = 170;
            dataGridView1.Columns["unvan"].HeaderText = "kişi adı";
            dataGridView1.Columns["unvan"].Width = 100;
            dataGridView1.Columns["grup_adi"].HeaderText = "kişi grubu";
            
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 grupislemler = new Form2();
            DialogResult result =grupislemler.ShowDialog();
            if(result == DialogResult.Cancel)
            {
                BilgileriYukle();
            }
        }
        private bool KayitKontrol()
        {
            bool kontrol = false;
            if(textBox1.TextLength<2)
            { MessageBox.Show("kişinin adını giriniz."); }
            else if (textBox3.TextLength < 2)
            {
                MessageBox.Show("kişinin soyadını giriniz.");
            }
            else if (textBox2.TextLength < 10 || textBox2.TextLength>14)
            {
                MessageBox.Show("kişinin numarasını giriniz(10-14 karakter olmalıdır).");
            }
            else if (comboBox2.SelectedIndex < 0)
            {
                MessageBox.Show("kişinin grubunu  seçiniz.");
            }
            else
            {
                kontrol = true;
            }
            return kontrol;
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled=!char.IsDigit(e.KeyChar)&&!char.IsControl(e.KeyChar);

        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textBox10_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
        private void Formutemizle()
        {
            textBox1.Clear();
            textBox2.Clear();
            dataGridView1.ClearSelection();
            textBox3.Clear();
            textBox4.Clear();
            textBox6.Clear();
            textBox7.Clear();
            secilikisiId = -1;
                


        }
        private void button2_Click(object sender, EventArgs e)
        {
            Formutemizle();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(KayitKontrol())
            {
                Kisi kisi=new Kisi();
                kisi.kisiAdi = textBox1.Text;
                kisi.kisiSoyadi = textBox3.Text;
                kisi.TelNo1 = textBox2.Text;
                kisi.TelNo2 = textBox4.Text;
                kisi.Mail = textBox6.Text;
                kisi.Unvan = textBox7.Text;
                kisi.GrupId=Int32.Parse(comboBox2.SelectedValue.ToString());
                kisi.KisiEkle();
                dataGridView1.DataSource = kisi.KisileriListele();
                Formutemizle();

                    }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if(dataGridView1.SelectedRows!=null)
                {
                    secilikisiId=Convert.ToInt32(dataGridView1.CurrentRow.Cells["kisi_id"].Value.ToString());
                    textBox1.Text = dataGridView1.CurrentRow.Cells["ad"].Value.ToString();
                    textBox3.Text = dataGridView1.CurrentRow.Cells["soyad"].Value.ToString();
                    textBox2.Text = dataGridView1.CurrentRow.Cells["tel_no1"].Value.ToString();
                    textBox4.Text = dataGridView1.CurrentRow.Cells["tel_no2"].Value.ToString();
                    textBox6.Text = dataGridView1.CurrentRow.Cells["mail"].Value.ToString();
                    textBox7.Text = dataGridView1.CurrentRow.Cells["unvan"].Value.ToString();
                    comboBox2.Text = dataGridView1.CurrentRow.Cells["grup_adi"].Value.ToString();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message,"hata oluştu",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (secilikisiId != -1)
            {
                Kisi kisi=new Kisi();
                kisi.kisiId = secilikisiId;
                kisi.KisiSil();
                dataGridView1.DataSource = kisi.KisileriListele();
                Formutemizle();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (secilikisiId != -1)
            {
                if (KayitKontrol())
                {
                    Kisi kisi = new Kisi();
                    kisi.kisiId = secilikisiId;
                    kisi.kisiAdi = textBox1.Text;
                    kisi.kisiSoyadi = textBox3.Text;
                    kisi.TelNo1 = textBox2.Text;
                    kisi.TelNo2 = textBox4.Text;
                    kisi.Mail = textBox6.Text;
                    kisi.Unvan = textBox7.Text;
                    kisi.GrupId=Int32.Parse(comboBox2.SelectedValue.ToString());
                    kisi.KisiyiGuncelle();
                    dataGridView1.DataSource = kisi.KisileriListele();
                    Formutemizle();

                }
            }
        }
        private void KisiAra()
        {
            Kisi kisi=new Kisi();
            kisi.kisiAdi = textBox8.Text;
            kisi.kisiSoyadi = textBox9.Text;
            kisi.TelNo1 = textBox10.Text;
            kisi.GrupId = Int32.Parse(comboBox1.SelectedValue.ToString());
            dataGridView1.DataSource = kisi.KisiAra();

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            KisiAra();
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {
            KisiAra();
        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {
            KisiAra();
        }

        private void comboBox1_SelectionChangeCommitted(object sender, EventArgs e)
        {
            KisiAra();
        }
    }
}
