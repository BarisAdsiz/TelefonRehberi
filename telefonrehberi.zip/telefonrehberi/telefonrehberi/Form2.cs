﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static telefonrehberi.VeriTabaniBaglantisi;

namespace telefonrehberi
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        int seciliGrupId = -1;


        private void Form2_Load(object sender, EventArgs e)
        {
            Grup grup = new Grup();
            grdGruplar.DataSource = grup.GruplariListele();
            grdGruplar.Columns["grup_id"].HeaderText = "ID";
            grdGruplar.Columns["grup_id"].Width = 30;
            grdGruplar.Columns["grup_adi"].HeaderText = "Grup Adı";
            grdGruplar.Columns["grup_adi"].Width = 100;
            grdGruplar.Columns["aciklama"].HeaderText = "Açıklama";
        }

        private void btnEkleGrup_Click(object sender, EventArgs e)
        {
            Grup grup = new Grup();
            if(txtAciklamaGrup.TextLength < 2)
            {
                MessageBox.Show("Grup Adı Giriniz");
            }
            else
            {
                grup.GrupAdi = txtGrupAdiGrup.Text;
                grup.Aciklama = txtAciklamaGrup.Text;
                grup.GrupEkle();
                grdGruplar.DataSource = grup.GruplariListele();
                FormuTemizle();
            }
        }

        private void FormuTemizle()
        {
            txtGrupAdiGrup.Clear();
            txtAciklamaGrup.Clear();
            grdGruplar.ClearSelection();
            seciliGrupId = -1;
        }

        private void btnYeniKayıtGrup_Click(object sender, EventArgs e)
        {
            FormuTemizle();
        }

        private void grdGruplar_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            try
            {
                seciliGrupId = Convert.ToInt32(grdGruplar.CurrentRow.Cells["grup_id"].Value.ToString());
                txtGrupAdiGrup.Text = grdGruplar.CurrentRow.Cells["grup_adi"].Value.ToString();
                txtAciklamaGrup.Text = grdGruplar.CurrentRow.Cells["aciklama"].Value.ToString();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Hata Oluştu", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSilGrup_Click(object sender, EventArgs e)
        {
            if(seciliGrupId != -1)
            {
                Grup grup = new Grup();
                grup.GrupId = seciliGrupId;
                grup.GrupSil();
                grdGruplar.DataSource = grup.GruplariListele();
                FormuTemizle();
            }
        }

        private void btnGuncelleGrup_Click(object sender, EventArgs e)
        {
            if (seciliGrupId != -1)
            {
                if (txtGrupAdiGrup.TextLength < 2)
                    MessageBox.Show("Grup Adı Giriniz");

                else {
                    Grup grup = new Grup
                    {
                        GrupId = seciliGrupId,
                        GrupAdi = txtGrupAdiGrup.Text,
                        Aciklama = txtAciklamaGrup.Text
                    };

                    grup.GrubuGuncelle();
                    grdGruplar.DataSource = grup.GruplariListele();
                    FormuTemizle();
                }
            }
        }
    }
}
