﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Windows.Forms;

namespace telefonrehberi
{
    internal class VeriTabaniBaglantisi
    {
        string baglantiCumlesi = ConfigurationManager.ConnectionStrings["TelefonRehberiBaglantiCumlesi"].ConnectionString;

        public SqlConnection baglan()
        {
            SqlConnection baglanti = new SqlConnection(baglantiCumlesi);
            SqlConnection.ClearPool(baglanti);
            return baglanti;
        }

        public class Kisi
        {
            public int kisiId { get; set; }
            public string kisiAdi { get; set; }
            public string kisiSoyadi { get; set; }
            public string TelNo1 { get; set; }
            public string TelNo2 { get; set; }
            public string Mail { get; set; }
            public string Unvan { get; set; }
            public int GrupId { get; set; }
            VeriTabaniBaglantisi veriTabaniBaglantisi;
            SqlConnection baglanti;
            SqlCommand komut;


            public Kisi()
            {
                veriTabaniBaglantisi = new VeriTabaniBaglantisi();
                baglanti = veriTabaniBaglantisi.baglan();
                komut = new SqlCommand();
                komut.Connection = baglanti;
            }
            
            public void KisiEkle() {

                try
                {
                    if (baglanti.State != ConnectionState.Open)
                        baglanti.Open();

                    komut.CommandText = "INSERT INTO kisiler(ad,soyad,tel_no1,tel_no2,mail,unvan,grup_id)" + "VALUES(@ad,@soyad,@tel_no1,@tel_no2,@mail,@unvan,@grup_id)";

                    komut.Parameters.AddWithValue("@ad", kisiAdi);
                    komut.Parameters.AddWithValue("@soyad", kisiSoyadi);
                    komut.Parameters.AddWithValue("@tel_no1", TelNo1);
                    komut.Parameters.AddWithValue("@tel_no2", TelNo2);
                    komut.Parameters.AddWithValue("@mail", Mail);
                    komut.Parameters.AddWithValue("@unvan", Unvan);
                    komut.Parameters.AddWithValue("@grup_id", GrupId);
                    komut.ExecuteNonQuery();
                    baglanti.Close();
                    MessageBox.Show("Kayıt İşlemi Başarılı");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Kayıt İşleminde Hata oluştu", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
            public void KisiyiGuncelle() {

                try
                {
                    if (baglanti.State != ConnectionState.Open)
                        baglanti.Open();

                    komut.CommandText = "UPDATE kisiler SET ad=@ad,soyad=@soyad,tel_no1=@telNo1,tel_no2=@telNo2,mail=@mail,unvan=@unvan,grup_id=@grupId";
                    komut.Parameters.AddWithValue("@ad", kisiAdi);
                    komut.Parameters.AddWithValue("@soyad", kisiSoyadi);
                    komut.Parameters.AddWithValue("@telNo1", TelNo1);
                    komut.Parameters.AddWithValue("@telNo2", TelNo2);
                    komut.Parameters.AddWithValue("@mail", Mail);
                    komut.Parameters.AddWithValue("@unvan", Unvan);
                    komut.Parameters.AddWithValue("@grupId", GrupId);
                    komut.ExecuteNonQuery();
                    baglanti.Close();
                    MessageBox.Show("Güncelleme İşlemi Başarılı");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Güncelleme İşleminde Hata oluştu", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
            public void KisiSil() {

                try
                {
                     if (baglanti.State != ConnectionState.Open)
                        baglanti.Open();

                    komut.CommandText = "DELETE FROM kisiler WHERE kisi_id=@kisiID";
                    komut.Parameters.AddWithValue("kisiId", kisiId);
                    komut.ExecuteNonQuery();
                    baglanti.Close();
                    MessageBox.Show("Silme işlemi Başarılı");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Silme İşleminde Hata oluştu", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
            public DataTable KisileriListele() {

                try
                {
                    komut.CommandText = "SELECT kisi_id,ad,soyad,tel_no1,tel_no2,mail,unvan,grup_adi FROM kisiler, guruplar " + "WHERE kisiler.grup_id = guruplar.grup_id ORDER BY ad ASC, soyad ASC";
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(komut);
                    DataTable kisiListesi = new DataTable();
                    dataAdapter.Fill(kisiListesi);
                    return kisiListesi;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Listeleme İşleminde Hata oluştu", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return null;
                }

            }
            public DataTable KisiAra() { 
            
                try
                {
                    if(GrupId == 0)
                    {
                        komut.CommandText = "SELECT kisi_id,ad,soyad,tel_no1,tel_no2,mail,unvan,grup_adi FROM kisiler, guruplar" +
                                            "WHERE kisiler.grup_id=guruplar.grup_id and ad LIKE @ad and soyad LIKE @soyad and" +
                                            "(tel_no1 LIKE @telNo1 or tel_no2 LIKE @TelNo1) ORDER BY ad ASC, soyad ASC"; 
                    }
                    else
                    {
                        komut.CommandText = "SELECT kisi_id,ad,soyad,tel_no1,tel_no2,mail,unvan,grup_adi FROM kisiler, guruplar" +
                                            "WHERE kisiler.grup_id=guruplar.grup_id and ad LIKE @ad and soyad LIKE @soyad and" +
                                            "(tel_no1 LIKE @telNo1 or tel_no2 LIKE @TelNo1) and guruplar.grup_id=@grupId ORDER BY ad ASC, soyad ASC";
                    }

                    komut.Parameters.AddWithValue("@ad", kisiAdi + "%");
                    komut.Parameters.AddWithValue("@soyad", kisiSoyadi+ "%");
                    komut.Parameters.AddWithValue("@telNo1", TelNo1 + "%");
                    komut.Parameters.AddWithValue("@grupId", GrupId + "%");
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(komut);
                    DataTable arananKisiListesi = new DataTable();
                    dataAdapter.Fill(arananKisiListesi);
                    return arananKisiListesi;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Arama İşleminde Hata oluştu", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return null;
                }

            }

        }

        public class Grup
        {
            public int GrupId { get; set; }
            public string GrupAdi { get; set; }
            public string Aciklama{ get; set; }

            VeriTabaniBaglantisi VeriTabaniBaglantisi;
            SqlConnection baglanti;
            SqlCommand komut;
            
            public Grup()
            {
                VeriTabaniBaglantisi = new VeriTabaniBaglantisi();
                baglanti = VeriTabaniBaglantisi.baglan();
                komut = new SqlCommand();
                komut.Connection = baglanti;
            }

            public void GrupEkle() {

                try
                {
                    if(baglanti.State != ConnectionState.Open)
                        baglanti.Open();

                    komut.CommandText = "INSERT INTO guruplar(grup_adi,aciklama)" + "VALUES (@grup_adi, @aciklama)";
                    komut.Parameters.AddWithValue("@grup_adi", GrupAdi);
                    komut.Parameters.AddWithValue("@aciklama", Aciklama);
                    komut.ExecuteNonQuery();
                    MessageBox.Show("Kayıt İşlemi Başarılı");
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message, "Kayıt İşleminde Hata Oluştu", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                baglanti.Close();
            }
            public void GrubuGuncelle() {

                try
                {
                    if (baglanti.State != ConnectionState.Open)
                        baglanti.Open();

                    komut.CommandText = "UPDATE guruplar SET grup_adi=@grupAdi, aciklama=@aciklama" + "WHERE grup_id=@grupId";
                    komut.Parameters.AddWithValue("@grupAdi", GrupAdi);
                    komut.Parameters.AddWithValue("@aciklama", Aciklama);
                    komut.Parameters.AddWithValue("@grupId", GrupId);
                    komut.ExecuteNonQuery();
                    MessageBox.Show("Güncelleme İşlemi Başarılı");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Güncelleme İşleminde Hata Oluştu", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                baglanti.Close();

            }
            public void GrupSil() {

                try
                {
                    if (baglanti.State != ConnectionState.Open)
                        baglanti.Open();

                    komut.CommandText = "DELETE FROM guruplar WHERE grup_id=@grupId";
                    komut.Parameters.AddWithValue("@grupId", GrupId);
                    komut.ExecuteNonQuery();
                    MessageBox.Show("Silme İşlemi Başarılı");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Silme İşleminde Hata Oluştu", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                baglanti.Close();

            }
            public DataTable GruplariListele() {

                try
                {
                    komut.CommandText = "SELECT * FROM guruplar ORDER BY grup_adi ASC";
                    SqlDataAdapter dataAdapter =  new SqlDataAdapter(komut);
                    DataTable grupListesi = new DataTable();
                    dataAdapter.Fill(grupListesi);
                    return grupListesi;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Listeleme İşleminde Hata Oluştu", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return null;
                }

            }

        }
    }
}
